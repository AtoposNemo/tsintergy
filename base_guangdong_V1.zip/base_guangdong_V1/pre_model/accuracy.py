import pandas as pd 
import numpy as np 
from datetime import datetime
from datetime import timedelta
from pre_model.models import Models

class Preprotection():
    def _init__(self,data):
        self.data = data 
    
    def acc(self,actual_load_data,predicted_load_data,max_bus_load):
        result = pd.DataFrame(100 - np.sqrt(np.sum(
            ((actual_load_data.loc[:, 't0000':'t2345'] - predicted_load_data.loc[:, 't0000':'t2345']) /
             actual_load_data.loc[:, 't0000':'t2345'].applymap(
                 lambda x: x if x >= 20 else max_bus_load * 0.5
            )) ** 2, axis=1) / 96) * 100, columns=['precision'])

        return result
    def protection_active(self,data,weather,window,max_bus_load,info_point,model_name,end_time):
        left = 0
        right = window 
        pro_res = pd.DataFrame()
        #窗口 预测
        while right < len(data):
            train_data = data.iloc[left:right+1][:]
            train_weather = weather.iloc[left:right+1][:]
            #这里可以更换模型，具体有
            #Models().var_model ，prophet   
            res_one_time = eval('Models().'+model_name+'(train_data,train_weather,window)')   
            pro_res = pd.concat([pro_res,res_one_time],axis = 0) 
            left += 1
            right += 1     
        
        #准确率计算，以及表拼接 首先取实际数
        actual_data = (data.iloc[window:,:97])
        actual_data.index=[actual_data['date_time']]
        actual_data = actual_data.drop(['date_time'],axis = 1)
        actual_data.columns = pro_res.columns   
        pro_acc= self.acc(actual_data,pro_res,max_bus_load)
        actual_data,pro_res,pro_acc= actual_data.reset_index(),pro_res.reset_index(),pro_acc.reset_index()     
        #预测回填
        lenth = info_point
        if lenth > 0:
            last_pro = pro_res.iloc[-1:][:].values[0]
            last_data = data.iloc[-1:][:].values[0]
            diff = sum(last_data[1:lenth+1])/lenth - sum(last_pro[1:lenth+1])/lenth 
            if diff > 0 :
                  last_pro[1:] = last_pro[1:] - diff 
            else : 
                  last_pro[1:] = last_pro[1:] + diff 
            last_pro = pd.DataFrame(last_pro).T
            last_pro.columns = actual_data.columns
            actual_data[-1:][1:97] = last_pro
            last_date = datetime.strptime(end_time, "%Y-%m-%d")
            last_date = last_date + timedelta(days=1)
            last_date =datetime.strftime(last_date, "%Y-%m-%d")
            actual_data.fillna(last_date,inplace = True)
            actual_data = actual_data.reset_index().drop(['index'],axis = 1)
        #调用一次预测函数
        train_data_last = actual_data.iloc[-window:][:]
        train_weather_last = weather.iloc[-window:][:]
        res_one_time = Models().var_model(train_data_last,train_weather_last,window)
        pro_res = pd.concat([pro_res,res_one_time],axis = 0).reset_index().drop(['index'],axis = 1) 
        
        last_date = datetime.strptime(end_time, "%Y-%m-%d")
        last_date = last_date + timedelta(days=2)
        last_date =datetime.strftime(last_date, "%Y-%m-%d")
        pro_res.fillna(last_date,inplace = True)
        return actual_data[:-1][:],pro_res,pro_acc
       





        
