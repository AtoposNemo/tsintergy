from numpy import nan, full
from pandas import DataFrame, Timestamp, date_range, merge
import pandas as pd

class DfTypeTrans():

    def __init__(self,index_name):
        self.freq_list_96 = ['T' + str(i) for i in range(1, 97)]
        self.freq_list_48 = self.freq_list_96[::2]
        self.freq_list_24 = self.freq_list_96[::4]
        self.index_name = index_name
        self.numday2freqlist = {
            96: self.freq_list_96,
            48: self.freq_list_48,
            24: self.freq_list_24
        }
        self.numday2freq = {96: '15min',
                            48: '30min',
                            24: '1h'}

    def table2col(self, data, col_name, numday=96):
        if self.index_name not in data.columns and self.index_name == data.index.name:
            data.reset_index(inplace=True)
        data.columns = [self.index_name]+self.numday2freqlist[numday]
        if not isinstance(data.loc[:, self.index_name][0], DataFrame):
            data.loc[:, self.index_name] = data.loc[:, self.index_name].apply(lambda x: Timestamp(str(x)))
        start_time, end_time = Timestamp(str(data.loc[:, self.index_name].min())[0:10] + ' 00:00:00'), \
                               Timestamp(str(data.loc[:, self.index_name].max())[0:10] + ' 23:45:00')
        data.set_index(self.index_name, inplace=True)
        data_new = DataFrame(data=date_range(start_time, end_time, freq=self.numday2freq[numday]), columns=[self.index_name])
        data_new.set_index([self.index_name], inplace=True)
        data_new[col_name] = nan
        for day in date_range(start_time, end_time, freq='1d'):
            day = str(day)[0:10]
            try:
                data_oneday = data.loc[day, :].values.flatten()
                if data_oneday.shape[0] < numday:
                    data_oneday = full([1, numday], nan)
            except:
                data_oneday = full([1, numday], nan)

            data_new.loc[day, col_name] = data_oneday
        return data_new

    def col2table(self, data, col_name='gl', numday=96):
        if self.index_name not in data.columns and self.index_name == data.index.name:
            data.reset_index(inplace=True)
        col_name_new_list = [self.index_name] + self.numday2freqlist[numday]
        if not isinstance(data.loc[:, self.index_name][0], Timestamp):
            data.loc[:, self.index_name] = data.loc[:, self.index_name].apply(lambda x: Timestamp(str(x)))
        data_new = DataFrame(columns=col_name_new_list)
        start_time, end_time = Timestamp(str(data.loc[:, self.index_name].min())[0:10] + ' 00:00:00'), \
                               Timestamp(str(data.loc[:, self.index_name].max())[0:10] + ' 23:45:00')
        df_time = DataFrame(data=date_range(start_time, end_time, freq=self.numday2freq[numday]), columns=[self.index_name])
        data = merge(df_time, data, on=self.index_name, how='outer').set_index(self.index_name)
        data_new.loc[:, self.index_name] = date_range(start_time, end_time, freq='1d')
        data_new.set_index(self.index_name, inplace=True)
        for day in date_range(start_time, end_time, freq='1d'):
            day = str(day)[0:10]
            data_one = data.loc[day, col_name].values.flatten().tolist()
            data_new.loc[day, :] = data_one
        return data_new.reset_index()
    
    def table2informatter(self,col_data):
        col_data[self.index_name] = col_data[self.index_name].apply(lambda x:x.strftime('%Y%m%d'))
        col_data.reset_index(inplace=True)
        col_data['index'] = '#'
        result = col_data.rename({"index":"@",self.index_name:"Date"},axis=1)
        result = result.replace(nan,"null")
        return result

#测试
# dftypetrans = DfTypeTrans('date_time')
# data = pd.read_csv(r'D:\tscode\base_guangdong\data\bus_load_his_restore_normal_2022.csv')
# data.drop(['t2400','updatetime','createtime','id','city_id','station_id','bus_id'],axis = 1,inplace = True)
# data['date_time']=pd.to_datetime(data['date_time'],format='%d/%m/%Y').dt.normalize()
# data= data.sort_values(by=['date_time']).reset_index().drop(['index'],axis=1)
# data = data.iloc[:10,:]
# #print(dftypetrans.table2col(data,'value'))
# print(dftypetrans.table2informatter(data))

