import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签
plt.rcParams['axes.unicode_minus']=False #用来正常显示负号
use_columns = ['DATE', 'T0000', 'T0015', 'T0030', 'T0045', 'T0100', 'T0115', 'T0130', 'T0145', 'T0200', 'T0215', 'T0230', 'T0245',
 'T0300', 'T0315', 'T0330', 'T0345', 'T0400', 'T0415', 'T0430', 'T0445', 'T0500', 'T0515', 'T0530', 'T0545', 'T0600',
 'T0615', 'T0630', 'T0645', 'T0700', 'T0715', 'T0730', 'T0745', 'T0800', 'T0815', 'T0830', 'T0845', 'T0900', 'T0915',
 'T0930', 'T0945', 'T1000', 'T1015', 'T1030', 'T1045', 'T1100', 'T1115', 'T1130', 'T1145', 'T1200', 'T1215', 'T1230',
 'T1245', 'T1300', 'T1315','T1330', 'T1345', 'T1400', 'T1415', 'T1430', 'T1445', 'T1500', 'T1515', 'T1530', 'T1545',
 'T1600', 'T1615', 'T1630', 'T1645', 'T1700', 'T1715', 'T1730', 'T1745', 'T1800', 'T1815', 'T1830', 'T1845', 'T1900',
 'T1915', 'T1930','T1945', 'T2000', 'T2015', 'T2030', 'T2045', 'T2100', 'T2115', 'T2130', 'T2145','T2200', 'T2215',
 'T2230', 'T2245', 'T2300', 'T2315', 'T2330', 'T2345']
def read_fc_load(path):
    '''
    Given a path, read the forecast data in the file and return the forecast dataframe
    '''
    encoding = 'ISO-8859-1'
    with open(path,mode='r',encoding=encoding,errors='ignore') as out_reader:
        content_list = out_reader.readlines()
        mask = [True if x.find('#')>=0 else False for x in content_list]
        content = pd.Series(content_list)[mask]
        begin_num = content.index.min()
        end_num = content.index.max()

        fc_load = pd.read_table(path,encoding=encoding,skiprows=begin_num,header=None,nrows=end_num-begin_num+1,sep='\s+')

        fc_load[1]= fc_load[1]#.apply(lambda x:''.join(x.split('-')))
        return fc_load
    
# 获取所有预测结果
def get_all_fc_data(pattern):
    '''
    Given a patten, read all the forecast data return the dataframe
    '''
    all_fc_date = os.listdir(f'./{pattern}/')
    fc_df = pd.DataFrame()
    for date in all_fc_date:
        try:
            path = f'./{pattern}/{date}/FILE_OUT.e'
            these_fc_load = read_fc_load(path)#可能时多天的dataframe
            these_fc_load[0] = date # 第一个预测日赋值给 0 列
            fc_df = pd.concat([fc_df,these_fc_load],axis=0)
        except Exception as e:
            print(e)
            pass
    fc_df.reset_index(drop=True,inplace=True)
    fc_df.columns = ['first_fc_date','fc_date'] + use_columns[1:]
    fc_df['first_fc_date'] = fc_df['first_fc_date'].apply(lambda x:pd.to_datetime(str(x)))
    
#     fc_df['fc_date'].apply(lambda x:pd.Timestamp(print(x)))
    
    fc_df['fc_date'] = fc_df['fc_date'].apply(lambda x:pd.to_datetime(str(x)))
    
    return fc_df

def get_num_fc_data(fc_df,num_fc_day=1):
    '''
    extract the forecast data of the n-th forecast day, return the dataframe
    '''
    num_each_fc = int(np.ceil(len(fc_df['fc_date'].drop_duplicates())/len(fc_df['first_fc_date'].drop_duplicates())))
    if num_fc_day>num_each_fc:
        raise ValueError(f'In each prediction,the algorithm only predicts {num_each_fc} day,please set the parameter num_fc_day<={num_each_fc}') 
    # todo
    mask = fc_df['fc_date'] == fc_df['first_fc_date'] + pd.Timedelta(num_fc_day-1,unit='days')
    fc_df = fc_df.loc[mask].iloc[:,1:].copy()
    return fc_df

def read_his_laod(path):
    '''
    given a path, read the his_load(formatted).
    '''
    his_load = pd.read_excel(path)
    his_load['Date'] = his_load['Date'].apply(lambda x:pd.Timestamp(str(x)))
    his_load.drop(['@'],axis=1,inplace=True)
    his_load.columns = use_columns
    return his_load
def RMSPE(his,fc):

#     his = his.max()
#     fc = fc.max()
    return (1-np.sqrt((((his - fc)/his)**2).mean()))*100


# todo 
def MAX_VALUE_RMSPE(his,fc):
    
    # 找到最大负荷发生时刻
    #print(his)
    ind = np.argmax(his)
    his = his[ind]
    fc = fc[ind]
    return (1-np.sqrt((((his - fc)/his)**2).mean()))*100


def curve_similary_measure(his,fc):

    his_norm = his/his.max()
    fc_norm = fc/fc.max()
    return (1-np.sqrt((((his_norm - fc_norm)/his_norm)**2).mean()))*100

def acc_stat_all(his_load,fc_loads,pattern = 'remove_holiday',mode='accuracy',holiday_path='./holiday.txt'):
    '''
    
    '''
    #todo去除节假日
    num_each_fc = int(np.ceil(len(fc_loads['fc_date'].drop_duplicates())/len(fc_loads['first_fc_date'].drop_duplicates())))
    for fth in range(1,num_each_fc+1):
        fc_load = get_num_fc_data(fc_loads,num_fc_day=fth)
        
        acc_stat_each_df = acc_stat_each(his_load,fc_load,pattern,mode,holiday_path)
        acc_stat_each_df.rename(columns={'acc':'acc_day'+str(fth)},inplace=True)
        if fth ==1:
            acc_stat_all_df=acc_stat_each_df
        else:
            acc_stat_all_df=pd.merge(acc_stat_all_df,acc_stat_each_df,on='date')
            
    return acc_stat_all_df
def acc_stat_each(his_load,fc_load,pattern,mode,holiday_path):
    '''
    
    '''
    if pattern == 'remove_holiday':
        holiday_info = pd.read_table(holiday_path,sep='\s+')
        holiday = holiday_info['Date']
        holiday= [pd.Timestamp(str(x)) for x in holiday]
        holiday_set = set(holiday)
    else:
        holiday_set = set()
    date_set = set(his_load['DATE']) - holiday_set
    use_dates = [date for date in fc_load['fc_date'] if date in date_set]
    date_list = []
    acc_list = []
    for date in use_dates:
        his = np.array(his_load.loc[his_load['DATE']==date].iloc[:,1:]).flatten()
        fc = np.array(fc_load.loc[fc_load['fc_date']==date].iloc[:,1:]).flatten()
        if mode == 'accuracy':
            acc = RMSPE(his,fc)
        elif mode == 'max_value_accuracy':
            acc = MAX_VALUE_RMSPE(his,fc)
        elif mode == 'similarity':
            acc = curve_similary_measure(his,fc)
        else:
            raise ValueError(f'please input correct [mode] parameter,[accuracy] or [similarity] ') 
        date_list.append(date)
        acc_list.append(acc)
    acc_stat_each_df = pd.DataFrame({'date':date_list,'acc':acc_list})
    
    return acc_stat_each_df

def acc_stat_by_month(acc_df):
    acc_df_ = acc_df.copy()
    acc_df_['month'] = acc_df_['date'].apply(lambda x:x.month)
    month_list  =acc_df_['month'].drop_duplicates().sort_values().tolist()
    for month in month_list:
        month_acc_stat = acc_df_.loc[acc_df_['month']==month].drop(['month'],axis=1).describe().T
        print(str(month)+'月份：')
        display(month_acc_stat)
        
def data_fomator(df_raw):
    use_columns = ['DATE', 'T0000', 'T0015', 'T0030', 'T0045', 'T0100', 'T0115', 'T0130', 'T0145', 'T0200', 'T0215', 'T0230', 'T0245',
 'T0300', 'T0315', 'T0330', 'T0345', 'T0400', 'T0415', 'T0430', 'T0445', 'T0500', 'T0515', 'T0530', 'T0545', 'T0600',
 'T0615', 'T0630', 'T0645', 'T0700', 'T0715', 'T0730', 'T0745', 'T0800', 'T0815', 'T0830', 'T0845', 'T0900', 'T0915',
 'T0930', 'T0945', 'T1000', 'T1015', 'T1030', 'T1045', 'T1100', 'T1115', 'T1130', 'T1145', 'T1200', 'T1215', 'T1230',
 'T1245', 'T1300', 'T1315','T1330', 'T1345', 'T1400', 'T1415', 'T1430', 'T1445', 'T1500', 'T1515', 'T1530', 'T1545',
 'T1600', 'T1615', 'T1630', 'T1645', 'T1700', 'T1715', 'T1730', 'T1745', 'T1800', 'T1815', 'T1830', 'T1845', 'T1900',
 'T1915', 'T1930','T1945', 'T2000', 'T2015', 'T2030', 'T2045', 'T2100', 'T2115', 'T2130', 'T2145','T2200', 'T2215',
 'T2230', 'T2245', 'T2300', 'T2315', 'T2330', 'T2345']
    df_raw.columns = use_columns
    df = df_raw.reset_index(drop=True)
    df = df.replace('<NULL>',np.nan)
    df['DATE'] = df['DATE'].apply(lambda x:pd.Timestamp(str(x)))
    left_df = df.iloc[:,:1]
    right_df = df.iloc[:,1:]
    df = pd.concat([left_df,right_df.astype(float)],axis=1)
    df = df.sort_values('DATE')
    return df

def save_data(df,path=''):
    df = df.reset_index().rename({'index':'@','DATE':'Date'},axis=1)
    df['@'] = '#'
    df = df.fillna('null')
    df['Date'] = df['Date'].apply(lambda x:x.strftime('%Y%m%d'))
    df.to_excel(path,index=None)