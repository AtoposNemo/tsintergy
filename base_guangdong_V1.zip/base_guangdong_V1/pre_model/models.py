import pandas as pd 
import numpy as np 
from datetime import datetime
from datetime import timedelta
from statsmodels.tsa.vector_ar.var_model import VAR
from prophet import Prophet 
from python_tools.tableandtools import *
#模型函数输入输出说明 ：
#输入为原数据，date_time+96点，共96列，包括负荷数据和天气数据,以及一个window
#返回值为一个预测结果 形式和输入相同
class Models:
    def _init__(self):
        pass
    def var_model(self,data,weather,window):
        
        df = pd.merge(data,weather,on='date_time',how = 'left')
        time = (weather[window:]['date_time']).reset_index().drop(['index'],axis=1)
        df.index=[df['date_time']]
        df = df.drop(['date_time'],axis = 1)
       
        df = df.fillna(0)
        #df_train,df_test = df[0:len(df)-1], df[len(df)-1:]
        model = VAR(df)
        model_fit = model.fit(2)
        sample_pro= model_fit.forecast(df.values[-2:],steps = 1)
        res = sample_pro[:][0:96]
        col_list = list(df.columns[:96])
        #预测结果存为pd并且列名还原
        for i in range(len(col_list)) : 
            col_list[i] = col_list[i][0:5] 
        res = pd.DataFrame(sample_pro[0][0:96]).T
        res.columns = col_list
        #时间戳作为索引
        res['date_time'] = time['date_time']
        res.index=[res['date_time']]
        res = res.drop(['date_time'],axis = 1)
        return res
    #模型测试  
    def  prophet_model(self,data,weather,window):
        #进行数据转化 
        cols = data.columns
        dftypetrans = DfTypeTrans('date_time')       
        data,weather = dftypetrans.table2col(data,'y'),dftypetrans.table2col(weather,'weather')
        data_weather = pd.merge(data,weather,on='date_time',how = 'left')
        
        data_weather = data_weather.reset_index() 
        data_weather.columns = ['ds','y','weather']
        data_weather.index = data_weather['ds']
        #预测建模
        model = Prophet(changepoint_prior_scale=1.0,interval_width=0.9,growth='linear',changepoint_range=0.95) 
        model.fit(data_weather) 
        future = model.make_future_dataframe(periods = 96,freq = "15min")
        forecast = model.predict(future)
        forecast= forecast.iloc[:,0:2]
        forecast.columns = ['date_time','pro_res']
        pro_data = dftypetrans.col2table(forecast,'pro_res')#[window:][:]
        pro_data.columns = cols
        return  pro_data