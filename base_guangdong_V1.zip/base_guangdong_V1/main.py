from read_data.read_data_sql import ReadDataSql
from read_data.read_para import ReadPara
from pre_model.accuracy import Preprotection 
from python_tools.tableandtools import *
from draw_line.pro_line import DrawLine
from pre_model.models import Models
from datetime import datetime
from datetime import timedelta
class MainFlow:
    def __init__(self):
        pass
    @staticmethod
    def active_sql():
        start_time,end_time,bus_id,window,info_point,model_name_test = ReadPara().read_para()
        reading = ReadDataSql(start_time,end_time,bus_id,window)
        data_all,weather_all,bus_info = reading.select() 
        for i in range(len(bus_id)):
            #注意，取数时，为了方便填充，天气数据比负荷数据多取了一天
            pro_acc_all = pd.DataFrame()
            data,weather,max_load = reading.data_one_bus(data_all,weather_all,bus_info,bus_id[i])
            actual_data,pro_res,pro_acc = Preprotection().protection_active(data,weather,window,max_load,info_point,model_name_test,end_time)  
            # #画图部分 
            DrawLine().draw(actual_data,pro_res,i)
            #保存精确度 
            pro_acc_all = pd.concat([pro_acc_all,pro_acc],axis = 0) 
            print(actual_data,pro_res)
            pro_acc_all.to_csv('acc_'+bus_id[i]+'.csv',index = False)
if __name__ == "__main__":     
    MainFlow().active_sql()  

    
    
    

