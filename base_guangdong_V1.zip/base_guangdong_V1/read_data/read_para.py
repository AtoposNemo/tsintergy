import os 
class ReadPara:
    def __init__(self):
        pass 
    def read_para(self):
        path = os.getcwd()
        f = open(path+"\\para.txt",'r',encoding = 'utf-8') 
        lines = f.readlines()
        dic = {}
        for line in lines:
            if line[0] != '<' and line[0] != ' ':
                i = line.index('=')
                dic[line[0:i].strip()] = line[i+1:].strip()
        start_time = dic['start_time']
        end_time = dic['end_time']
        bus_id = eval(dic['bus_id'])
        window = int(dic['window'])
        info_point = int(dic['info_point'])
        model_name_test = dic['model_name_test']
        return start_time,end_time,bus_id,window,info_point,model_name_test 


