import pandas as pd
import numpy as np
import pymysql
from datetime import datetime
from datetime import timedelta
class ReadDataSql:
    def __init__(self,start_time,end_time,bus_id,window):
        self.start_time=start_time
        self.end_time = end_time 
        self.bus_id = bus_id
        self.window = window
        conn = pymysql.connect(host = "192.168.3.98",port = 3306,
                user =  "tsintergy", password = "123456",
                database = "bus_guang_dev_v3_xianchang",charset = 'utf8')
        #得到一个可执行sql语句的光标对象 执行完毕返回的结果集默认以元组显示 
        cursor = conn.cursor()
        # 得到一个可以执行SQL语句并且将结果作为字典返回的游标
        cursor = conn.cursor(cursor=pymysql.cursors.DictCursor)
        self.cursor = cursor
        self.conn = conn
    def select(self):
        bus_id_str = str(tuple(self.bus_id))
        print('开始查询数据表')
        start_date = datetime.strptime(self.start_time, "%Y-%m-%d")
        start_pre = start_date - timedelta(days=self.window)
        start_pre =datetime.strftime(start_pre, "%Y-%m-%d")
        
        end_date = datetime.strptime(self.end_time, "%Y-%m-%d")
        end_one = end_date + timedelta(days=1)
        end_one =datetime.strftime(end_one, "%Y-%m-%d")
        #先定义天气sql
        weather_sql =  "select * from  weather_city_his_clct" + \
                       " where (date_time between "+"'"+start_pre+"'" + " and "+"'"+end_one+"'"+") and " + \
                        "type = " + str(2) 
        #处理时间，方便查数据
        start_pre = datetime.strptime(start_pre, "%Y-%m-%d")   
        #判断是否跨年，
        start_year = str(start_pre.year)
        end_year = str(end_date.year)
        start_pre = str(start_pre)[:10]
        table = "bus_load_his_restore_normal_"
        if  start_year == end_year:
            data_sql  = "select * from  "+ table+start_year + \
                        " where ( date_time between "+"'"+start_pre+"'" + \
                        " and "+"'"+end_one+"'"+" ) and bus_id in  " + bus_id_str
        else: #
            data_sql  = "select * from  "+ table+start_year + \
                " where date_time >="+"'"+start_pre+"'"+" and bus_id in " + bus_id_str
            for i in range(1,int(end_year)-int(start_year)):
                data_sql += " union select * from  "+ table+str(int(start_year)+i) + \
                        " where bus_id in " + bus_id_str
            data_sql += " union select * from  "+ table+str(int(start_year)+i) + \
                        " where date_time <="+"'"+end_one+"'" +" and bus_id in " + bus_id_str
              
        #查找信息表 
        info_sql = "select id , name, city_id ,capacity from base_bus_clct where forecast = 1 and id in " + bus_id_str  
        # 查询数据
        effect_data = self.cursor.execute(data_sql) 
        data = pd.DataFrame(self.cursor.fetchall())
        self.conn.commit()
        # 执行SQL语句 查询天气
        effect_weather = self.cursor.execute(weather_sql)
        weather =  pd.DataFrame(self.cursor.fetchall())
        self.conn.commit()
        #信息查询
        effect_info = self.cursor.execute(info_sql) 
        bus_info = pd.DataFrame(self.cursor.fetchall())
        self.conn.commit()
        # 关闭光标对象
        self.cursor.close()
        # 关闭数据库连接
        self.conn.close()
        print('查询负荷数据和天气数据完成！')
        #根据日期进行排序
        data['date_time']=pd.to_datetime(data['date_time'],format='%Y-%m-%d').dt.normalize()
        weather['date_time']=pd.to_datetime(weather['date_time'],format='%Y-%m-%d').dt.normalize()
        data = data.sort_values(by=['date_time']).reset_index().drop(['index'],axis=1)
        data = data[data['bus_id'].isin(self.bus_id)]        
        data.drop(['id','t2400','updatetime','createtime'],axis = 1,inplace = True)
        weather.drop(['id','t2400','updatetime','createtime'],axis=1,inplace = True)
        return data,weather,bus_info
    def data_one_bus(self,data,weather,bus_info,bus_id_one):
        #数据筛选，注意，sql中查到的pd，字段为obj型，应该转为float
        data = data[data['bus_id'] == bus_id_one]
        weather=weather.loc[weather['city_id'].isin(data['city_id'])]
        bus_info = bus_info[bus_info['id'] == bus_id_one]
        max_load = bus_info['capacity'].values[0]
        ##索引重建以进一步处理，主要是为了数据转化
        weather.index=[weather['date_time']]
        weather = weather.drop(['date_time'],axis = 1)
        data.index=[data['date_time']]
        data= data.drop(['date_time'],axis = 1)
        #数据转化，并且重建索引
        data=pd.DataFrame(data,dtype=np.float)
        weather=pd.DataFrame(weather,dtype=np.float)
        data = data.reset_index()
        weather = weather.reset_index()
     
        data['date_time']=pd.to_datetime(data['date_time'],format='%Y-%m-%d').dt.normalize()
        weather['date_time']=pd.to_datetime(weather['date_time'],format='%Y-%m-%d').dt.normalize()
        #删除不变的列
        data = data.drop(['city_id','station_id','bus_id'],axis=1)
        weather = weather.drop(['city_id','type'],axis=1)
        #填充 
        data.iloc[:][1:],weather.iloc[:][1:] = data.iloc[:][1:].interpolate(method='ffill'),weather.iloc[:][1:].interpolate(method='ffill')
        return data,weather,max_load
            
 
#测试 
# start_time = "2022-01-15"
# end_time = "2022-01-30"
# bus_id = ['117375065456117636','117375065456117624']
# getdata = ReadDataSql(start_time,end_time,bus_id,10)
# data,weather,info = getdata.select()
# print(data,weather,info)
# data,weather,max_load = getdata.data_one_bus(data,weather,info,'117375065456117636')
# print(data,weather,max_load)

        