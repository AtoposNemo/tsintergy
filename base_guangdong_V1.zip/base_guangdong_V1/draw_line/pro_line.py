import matplotlib 
from matplotlib import pyplot as plt
import numpy as np
from python_tools.tableandtools import *
plt.ion()
class DrawLine:
    def __init__(self):
        pass
    def call_back(self,event):
        axtemp = event.inaxes
        if axtemp:
            x_min, x_max = axtemp.get_xlim()
            fanwei = (x_max - x_min) / 10
            if event.button == 'up':
                axtemp.set(xlim=(x_min + fanwei, x_max - fanwei))
            elif event.button == 'down':
                axtemp.set(xlim=(x_min - fanwei, x_max + fanwei))
    def draw(self,actual_data,pro_data,i):
        
        dftypetrans = DfTypeTrans('date_time')       
        actual_data = dftypetrans.table2col(actual_data,'actual_load')
        pro_data = dftypetrans.table2col(pro_data,'pro_load')
        actual_data ,pro_data  = actual_data.reset_index(),pro_data.reset_index()  
          
        fig,axs1 = plt.subplots(figsize=(20,8)) 
        fig.canvas.mpl_connect('scroll_event', self.call_back)
        fig.canvas.mpl_connect('button_press_event', self.call_back)

        #画图
        axs1.plot(actual_data["date_time"],actual_data['actual_load'],label = 'actual_load',color='tab:red')
        axs1.plot(pro_data["date_time"],pro_data['pro_load'],label = 'pro_load',color='tab:blue')
        # 修饰
        axs1.set_ylabel('load', color='tab:red', fontsize=20)
        axs1.tick_params(axis='y', rotation=0, labelcolor='tab:red' )
        axs1.legend(loc='upper left')
        plt.pause(1) #显示秒数    
        plt.savefig(("result_"+str(i)+'.jpg'),bbox_inches='tight')
        plt.close()
        
        
        



        

